package jwsp.chapter7.stockaccount;

public class UnknownMemberLevelException extends RuntimeException {
    
    public UnknownMemberLevelException(String message) {
        super(message);
    }
    
}
