package jwsp.chapter7.stockaccount;

public interface StockDataSourceListener {
    
    public void handleNewStockData(PortfolioUpdate pu);
    
}
